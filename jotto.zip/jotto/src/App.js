import React from 'react';
import './App.css';
import Congrats from './Congrats';
import GuessWord from './GuessWord';
import Input from './Input';

import {getSecretWord} from './actions';

function App() {
  React.useEffect(()=>{
    getSecretWord();
  }, []);
  const guessWords =  [
  ];
  let sucess = false;
  let secretWord = "party";
  return (
    <div data-test="component-App" className="container">
      <h1 className='jotto'>Jotto</h1>
      <Congrats sucess={sucess} />
      <Input secretWord={secretWord} sucess={sucess}/>
      <GuessWord guessWords={guessWords} />
    </div>
  );
} 

export default App;
