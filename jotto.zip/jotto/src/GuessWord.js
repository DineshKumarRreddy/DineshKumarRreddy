import React from "react";
import PropTypes from "prop-types";

const GuessWord = (props) => {
  return (
    <div data-test="component-guessWord">
      {props.guessWords.length === 0 ? (
        <span data-test="guessword-instruction">
          Try to guess the secret word!
        </span>
      ) : (
        <div data-test="guessed-words">
          <h1>Guessed Words</h1>
          <table className="table table-sm table-bordered">
            <thead className="active">
              <tr>
                <th>Guess</th>
                <th>Matching Letters</th>
              </tr>
            </thead>
            <tbody>
              {props?.guessWords?.map((item, index) => (
                <tr key={index} data-test="num-words-guessed">
                  <td>{item.guessedWord}</td>
                  <td>{item.letterMatchCount}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};

GuessWord.propTypes = {
  guessWords: PropTypes.arrayOf(
    PropTypes.shape({
      guessedWord: PropTypes.string.isRequired,
      letterMatchCount: PropTypes.number.isRequired,
    })
  ).isRequired,
};

export default GuessWord;
