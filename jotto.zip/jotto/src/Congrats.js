import React from "react";
import PropTypes from "prop-types";

const Congrats = (props) => {
  return (
    <div data-test="congrats-component">
      {props.sucess && (
        <h2 data-test="congrats-msg" className="alert alert-success">
          "Cograsulations! you gussed the word"
        </h2>
      )}
    </div>
  );
};

Congrats.propTypes = {
    sucess: PropTypes.bool.isRequired,
};

export default Congrats;
