module.exports = {
    ...jest.requireActual(".."),
    __esModules: true,
    getSecretWord: jest.fn().mockReturnValue(Promise.resolve('party')),
}