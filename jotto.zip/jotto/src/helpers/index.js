const getLetterMatchCount = (guessWord, secretWord) => {
    const secretLetters = secretWord.split("");
    const guessLettersSet = new Set(guessWord);
    return secretLetters.filter(letter => guessLettersSet.has(letter)).length;
};

export {
    getLetterMatchCount,
}