import { getLetterMatchCount } from "./";

describe("getLetterMatchCount", () => {
    const secretWord = "party";
    it("returns correct count when there is no matching letters", () => {
        const count = getLetterMatchCount("bones",secretWord);
        expect(count).toBe(0);
    });
    it("return correct count when there are three matching letters", () => {
        const count = getLetterMatchCount("train",secretWord);
        expect(count).toBe(3);
    });
    it("return correct count when there are duplicate letters in the match", () => {
        const count = getLetterMatchCount("parka",secretWord);
        expect(count).toBe(3);
    });
});