import React from "react";
import { mount } from "enzyme";
import { findAttrsByDataTest } from "./test/testutils";

import App from "./App";
import {getSecretWord as mockSecretWord} from './actions';

jest.mock('./actions');

const setup = () => mount(<App />);

describe("render App", () => {
    it("render App without fail", () => {
        const wrapper = setup();
        const compApp = findAttrsByDataTest(wrapper, "component-App");
        expect(compApp).toHaveLength(1);
    })
});

describe("get scret word", () => {
    beforeEach(() => {
        mockSecretWord.mockClear();
    });

    it("get scret word on app mount", () => {
        const wrapper = setup();
        expect(mockSecretWord).toBeCalledTimes(1);
    });
    it("get scret word doesn't run on app mount", () => {
        const wrapper = setup();
        mockSecretWord.mockClear();
        wrapper.setProps();
        expect(mockSecretWord).toBeCalledTimes(0);
    });
});
