import React from "react";
import { shallow } from "enzyme";
import { findAttrsByDataTest, checkProps } from "./test/testutils";

import GuessWord from "./GuessWord";

let guessWords = [{ guessedWord: "car", letterMatchCount: 1 }];

const defaultProps = {
  guessWords,
};

const setup = (props = defaultProps) => shallow(<GuessWord {...props} />);

test("does not throw warning with expected props", () => {
  checkProps(GuessWord, defaultProps);
});

describe("if there are no words guessed", () => {
  let wrapper;
  const guessWords = [];
  beforeEach(() => {
    wrapper = setup({ guessWords });
  });

  it("renders the guessword component without fail", () => {
    const guessedWordComp = findAttrsByDataTest(wrapper, "component-guessWord");
    expect(guessedWordComp.length).toBe(1);
  });

  it("renders instructions to guess word", () => {
    const instGuessWord = findAttrsByDataTest(wrapper, "guessword-instruction");
    expect(instGuessWord.text()).not.toBe(0);
  });
});

describe("if there are words guessed", () => {
  let wrapper;
  const guessWords = [
    { guessedWord: "car", letterMatchCount: 1 },
    { guessedWord: "train", letterMatchCount: 3 },
    { guessedWord: "letters", letterMatchCount: 2 },
  ];
  beforeEach(() => {
    wrapper = setup({ guessWords });
  });

  it("renders guessword component without fail", () => {
    const guessedWordComp = findAttrsByDataTest(wrapper, "component-guessWord");
    expect(guessedWordComp.length).toBe(1);
  });

  it("renders guess word section", () => {
    const numberOfWordsGuessed = findAttrsByDataTest(
      wrapper,
      "num-words-guessed"
    );
    expect(numberOfWordsGuessed.length).toBe(3);
  });
});
