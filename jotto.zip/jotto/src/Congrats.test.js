import React from "react";
import { shallow } from "enzyme";

import Congrats from "./Congrats";
import { findAttrsByDataTest, checkProps } from "./test/testutils";

const congratsProps = {
  sucess: false,
};

const setup = (props = congratsProps) => shallow(<Congrats {...props} />);

test("render congrats component without fail", () => {
  const wrapper = setup();
  const congratsComp = findAttrsByDataTest(wrapper, "congrats-component");
  expect(congratsComp.length).toBe(1);
});

test("render no text display on `sucess` prop is false", () => {
    const wrapper = setup({sucess: false});
    const congMsg = findAttrsByDataTest(wrapper, "congrats-component").text();
    expect(congMsg).toBe('');
});

test("renders non-empty congrats text on `sucess` prop is true", () => {
    const wrapper = setup({sucess: true});
    const congMsg = findAttrsByDataTest(wrapper, "congrats-msg");
    expect(congMsg.text().length).not.toBe(0);
});

test("does not throw warning with expected props", () => {
    const expectedProps = {sucess: false};
    checkProps(Congrats, expectedProps);
});
