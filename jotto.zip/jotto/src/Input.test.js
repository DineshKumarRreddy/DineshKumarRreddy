import React from "react";
import { shallow } from "enzyme";
import { findAttrsByDataTest, checkProps } from "./test/testutils";

import Input from "./Input";

const word = "party";
const status = false;

const setup = (secretWord = word, sucess = status) =>
  shallow(<Input secretWord={secretWord} sucess={sucess} />);

it("Input renders without fail", () => {
  const wrapper = setup();
  const inputComp = findAttrsByDataTest(wrapper, "input-component");
  expect(inputComp.length).toBe(1);
});

it("does not throw warning with the expected props", () => {
  const props = { secretWord: "party", sucess: false };
  checkProps(Input, props);
});

describe("renders", () => {
  describe("sucess is false", () => {
    let wrapper;
    beforeEach(() => {
      wrapper = setup(undefined, false);
    });

    it("Input renders without fail", () => {
      const inputComp = findAttrsByDataTest(wrapper, "input-component");
      expect(inputComp.length).toBe(1);
    });

    it("input box does not show", () => {
      const input = findAttrsByDataTest(wrapper, "input-field");
      expect(input.exists()).toBe(true);
    });

    it("submit button renders on sucess false", () => {
      const input = findAttrsByDataTest(wrapper, "button-field");
      expect(input.exists()).toBe(true);
    });
  });

  describe("sucess is true", () => {
    let wrapper;
    beforeEach(() => {
      wrapper = setup(undefined, true);
    });

    it("Input renders without fail", () => {
      const inputComp = findAttrsByDataTest(wrapper, "input-component");
      expect(inputComp.length).toBe(1);
    });

    it("input box does not show", () => {
      const input = findAttrsByDataTest(wrapper, "input-field");
      expect(input.exists()).toBe(false);
    });

    it("submit button does not show", () => {
      const input = findAttrsByDataTest(wrapper, "button-field");
      expect(input.exists()).toBe(false);
    });
  });
});


describe("state controlled input field", () => {
    it("state update with value of input box upon change", () => {
        const mockSetGuessedWord = jest.fn();
        React.useState = jest.fn(() => ["", mockSetGuessedWord]);
        const wrapper = setup();
        const mockWord = {target:{value: "train"}}
        const inputField = findAttrsByDataTest(wrapper, "input-field");
        inputField.simulate("change", mockWord);
        expect(mockSetGuessedWord).toHaveBeenCalledWith("train");
    });

    it("state update with empty string on click of submit", () => {
        const mockSetGuessedWord = jest.fn();
        React.useState = jest.fn(() => ["", mockSetGuessedWord]);
        const wrapper = setup();
        const button = findAttrsByDataTest(wrapper, "button-field");
        button.simulate("click", {preventDefault() {}});
        expect(mockSetGuessedWord).toHaveBeenCalledWith("");
    });
});