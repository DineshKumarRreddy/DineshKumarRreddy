import checkPropTypes from "check-prop-types";

const findAttrsByDataTest = (wrapper, val) =>
  wrapper.find(`[data-test='${val}']`);

const checkProps = (component, compProps) => {
  const propError = checkPropTypes(component.propTypes, compProps, "prop", component.name);
  expect(propError).toBeUndefined();
};

export { findAttrsByDataTest, checkProps };
