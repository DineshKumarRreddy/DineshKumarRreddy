import React from "react";
import { mount } from "enzyme";
import { findAttrsByDataTest } from "./test/testutils";

import App from "./App";

let wrapper;

const setup = (state = {}) => {
  wrapper = mount(<App />);

  //add value to input box
  const inputFiels = findAttrsByDataTest(wrapper, "input-field");
  inputFiels.simulate("change", { target: { value: "train" } });

  //simulate the click on submit button
  const button = findAttrsByDataTest(wrapper, "button-field");
  button.simulate("click", { preventDefault() {} });

  return wrapper;
};

describe.skip("no word guessed", () => {
  let wrapper;
  beforeEach(() => {
    wrapper = setup({
      secretWord: "party",
      sucess: false,
      guessWords: [],
    });
  });

  it("creating guessword table with one row", () => {
    const guessWord = findAttrsByDataTest(wrapper, "num-words-guessed");
    expect(guessWord).toHaveLength(1);
  });
});

describe.skip("some words guessed", () => {
  let wrapper;
  beforeEach(() => {
    wrapper = setup({
      secretWord: "party",
      sucess: false,
      guessWords: [{guessedWord: "agile", letterMatchCount:""}],
    });
  });
  it("add rows to the guess words table", ()=> {
    const guessWord = findAttrsByDataTest(wrapper, "num-words-guessed");
    expect(guessWord).toHaveLength(2);
  });
});

describe.skip("guessed with correct word", () => {
  let wrapper;
  beforeEach(() => {
    wrapper = setup({
      secretWord: "party",
      sucess: false,
      guessWords: [{guessedWord: "agile", letterMatchCount:""}],
    });
    const inputBox = findAttrsByDataTest(wrapper, "input-field");
    const mockEvent = {target: {value: "party"}};
    inputBox.simulate("change", mockEvent);

    const submitButton = findAttrsByDataTest(wrapper, "button-field");
    submitButton.simulate("click", {preventDefault(){}});
  });
  it("add rows to the guess words table", ()=>{
    const guessWord = findAttrsByDataTest(wrapper, "num-words-guessed");
    expect(guessWord).toHaveLength(3);
  });
  it("display congrats component", ()=> {
    const congratsComp = findAttrsByDataTest(wrapper, "congrats-component");
    expect(congratsComp.text().length).toBeGreaterThan(0);
  });

  it("does not display input component content", ()=>{
    const inputBox = findAttrsByDataTest(wrapper, "input-field");
    expect(inputBox.exists()).toBeFalsy();

    const submitButton = findAttrsByDataTest(wrapper, "button-field");
    expect(submitButton.exists()).toBeFalsy();
  });
});
