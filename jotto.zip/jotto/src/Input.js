import React from "react";
import PropTypes from "prop-types";

// import {getLetterMatchCount} from "./helpers/index"

const Input = (props) => {
  const [guessWord, setGuessWord] = React.useState("");
  return (
    <div data-test="input-component">
      {!props.sucess && (
        <input
          data-test="input-field"
          type="text"
          placeholder="guess the word…"
          className="form-control form-control-lg"
          value={guessWord}
          onChange={(evt) => setGuessWord(evt.target.value)}
        />
      )}
      {!props.sucess && (
        <button
          data-test="button-field"
          className="btn btn-primary"
          onClick={(evt) => {
            evt.preventDefault();
            // getLetterMatchCount();
            setGuessWord("");
          }}
        >submit</button>
      )}
    </div>
  );
};

Input.propTypes = {
  secretWord: PropTypes.string.isRequired,
  sucess: PropTypes.bool.isRequired,
};

export default Input;
