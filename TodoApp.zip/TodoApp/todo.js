function checkTheKeyAndAdd (eve) {
  if(eve.key === 'Enter'){
    addItem();
  }
  console.log('Enter');
}

function addItem() {
  let list = document.getElementById("items-list");
  let value = document.getElementById("input").value;
  if (value.trim() !== "") {
    let item = document.createElement("div");
    let contentDiv = document.createElement("div");
    let buttonsDiv = document.createElement("div");
    let deleteBtn = document.createElement("button");
    let markBtn = document.createElement("button");

    contentDiv.classList.add("content");
    contentDiv.innerHTML = value;

    deleteBtn.classList.add("del-btn");
    deleteBtn.innerHTML = "Delete";
    deleteBtn.type = "button";

    markBtn.classList.add("mark-btn");
    markBtn.innerHTML = "Mark";
    markBtn.type = "button";

    buttonsDiv.classList.add('buttons');
    buttonsDiv.appendChild(markBtn);
    buttonsDiv.appendChild(deleteBtn);
    

    item.classList.add('item');
    item.onclick = () => {
      habdleItems(event);
    }
    item.appendChild(contentDiv);
    item.appendChild(buttonsDiv);

    list.appendChild(item);
    document.getElementById("input").value = "";
  }
}

const habdleItems = (eve) => {
  if(eve.target.textContent === 'Mark'){
    eve.currentTarget.children[0].className += ' textdecoretor';
    eve.target.textContent = 'UnMark'
  }
  else if(eve.target.textContent === 'UnMark'){
    eve.currentTarget.children[0].className = 'content';
    eve.target.textContent = 'Mark'
  }
  else if(eve.target.textContent === 'Delete'){
    eve.currentTarget.remove();
  }
}